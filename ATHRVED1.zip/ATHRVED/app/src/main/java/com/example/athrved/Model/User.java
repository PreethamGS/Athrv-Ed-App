package com.example.athrved.Model;

public class User {
    private  String id;


    public User(String id) {
        this.id = id;


    }
    public User(){

    }
}

